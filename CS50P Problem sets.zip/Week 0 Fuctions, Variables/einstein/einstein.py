#prompt the user for mass as an integer (in kilograms)
m = int(input("M: "))

#calculate the equivalent number of Joules
E = m * (300000000 ** 2)

print(E)

