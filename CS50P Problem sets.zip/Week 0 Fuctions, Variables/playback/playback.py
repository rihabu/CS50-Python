# prompt user for input
text = input("what's in your mind? ")

# replace each space with three dots
replaced_text = text.replace(" ", "...")

# return replaced output
print(replaced_text)
