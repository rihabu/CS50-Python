# prompt the user for input
text = input("what's in your mind? ")

# print in lowercase
print(text.lower())


